package com.movie.book.ticket.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.movie.book.ticket.app.dao.MovieTicketBookingDao;
import com.movie.book.ticket.app.entities.MovieTicket;

@Service
public class MovieTicketBookingService {

	@Autowired
	private MovieTicketBookingDao movieTicketBookingDao;

	public MovieTicket createMovieTicket(MovieTicket movieTicket) {
		return movieTicketBookingDao.save(movieTicket);
		
	}

	public MovieTicket getMovieTicketById(Integer ticketId) {
		return movieTicketBookingDao.findById(ticketId).get();
	}

	public Iterable<MovieTicket> getAllMovieTickets() {
		return movieTicketBookingDao.findAll();
	}

	public void deleteMovieTicketById(Integer ticketId) {
		movieTicketBookingDao.deleteById(ticketId);
	}
	
	public MovieTicket updateMovieTicket(Integer ticketId, String newEmail) {
		MovieTicket ticketFromDb = movieTicketBookingDao.findById(ticketId).get();
		ticketFromDb.setEmail(newEmail);
		MovieTicket upadedTicket = movieTicketBookingDao.save(ticketFromDb);
		return upadedTicket;
	}

}
